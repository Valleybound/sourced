import { useEffect, useRef, useState } from "react";
import { EyeOff, Axe, Beef, Circle, FlaskConical, Hammer, Heart, Pickaxe, Plus, Sword, Target, Zap } from "lucide-react";

import valley from "@/assets/paxdei-valley.jpg.asset.json";
import { cn } from "@/lib/utils";
import { allOptions, type MenuValues } from "./menu-data";

const HOTBAR = [
  { icon: Sword, label: "Iron Longsword", key: "1" },
  { icon: Axe, label: "Felling Axe", key: "2" },
  { icon: Pickaxe, label: "Pickaxe", key: "3" },
  { icon: Hammer, label: "Builder's Hammer", key: "4" },
  { icon: FlaskConical, label: "Healing Draught", key: "5" },
  { icon: Beef, label: "Roast Meat", key: "6" },
];
const COMPASS = ["W", "·", "NW", "·", "N", "·", "NE", "·", "E"];

// Made-up travellers placed in the valley (x = centre %, y = feet %, h = height % of view)
const PLAYERS = [
  { name: "Godric Thorne", clan: "Ironveil", x: 24, y: 70, h: 24, dist: 38, hp: 72, weapon: "Longbow", mate: false, hidden: false },
  { name: "Maud of Kerys", clan: "Ravenmoor", x: 71, y: 68, h: 19, dist: 64, hp: 100, weapon: "Spear", mate: true, hidden: false },
  { name: "Edwin Ashby", clan: "Black Fen", x: 56, y: 60, h: 13, dist: 112, hp: 41, weapon: "Mace", mate: false, hidden: false },
  { name: "Rowena Hale", clan: "Ironveil", x: 88, y: 56, h: 8, dist: 240, hp: 88, weapon: "Arming Sword", mate: false, hidden: true },
];
type Entity = { name: string; x: number; y: number; dist: number; kind: "animal" | "predator" | "resource" | "container" | "dropped" | "shrine"; type?: number };
const ENTITIES: Entity[] = [
  { name: "Grey Wolf", x: 38, y: 74, dist: 46, kind: "predator" },
  { name: "Red Deer", x: 10, y: 76, dist: 82, kind: "animal" },
  { name: "Wild Boar", x: 80, y: 77, dist: 120, kind: "animal" },
  { name: "Brown Bear", x: 94, y: 62, dist: 260, kind: "predator" },
  { name: "Iron Ore", x: 31, y: 50, dist: 58, kind: "resource", type: 1 },
  { name: "Copper Ore", x: 6, y: 58, dist: 180, kind: "resource", type: 1 },
  { name: "Oak Log", x: 63, y: 46, dist: 96, kind: "resource", type: 2 },
  { name: "Flax", x: 85, y: 70, dist: 34, kind: "resource", type: 3 },
  { name: "Comfrey", x: 47, y: 80, dist: 22, kind: "resource", type: 4 },
  { name: "Abandoned Chest", x: 42, y: 62, dist: 40, kind: "container" },
  { name: "Supply Crate", x: 66, y: 74, dist: 28, kind: "container" },
  { name: "Iron Ore ×12", x: 52, y: 72, dist: 18, kind: "dropped" },
  { name: "Wayside Shrine", x: 17, y: 46, dist: 210, kind: "shrine" },
];
const ESP_COLORS = ["text-primary", "text-warning", "text-success", "text-destructive"];
const ENTITY_COLORS: Record<Entity["kind"], string> = {
  animal: "text-foreground",
  predator: "text-destructive",
  resource: "text-warning",
  container: "text-primary",
  dropped: "text-success",
  shrine: "text-primary-glow",
};
const BONES = [0.09, 0.19, 0.32, 0.52];
const ARRAY_SKIP = new Set(["streamProof", "autosave", "watermark", "arrayList", "notifications", "keyHints", "compass", "clanMembers", "clanAlerts", "recipeTips", "durabilityWarn", "nameplates", "aimFovCircle", "aimVisible", "aimIgnoreClan", "aimLine", "hitMarkers", "damageNumbers", "espLabels", "espRadar", "antiAfk", "snapGrid", "espNames", "espClan", "espDistance", "espHealth"]);

export function GameScene({ values, menuOpen }: { values: MenuValues; menuOpen: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => e && setSize({ w: e.contentRect.width, h: e.contentRect.height }));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const on = (id: string) => Boolean(values[id]);
  const num = (id: string) => Number(values[id] ?? 0);
  const { w, h } = size;

  // Lighting
  const hour = num("timeOfDay");
  const daylight = hour >= 6 && hour <= 20 ? 0.6 + 0.55 * Math.sin((Math.PI * (hour - 6)) / 14) : 0.5;
  const light = on("fullbright") ? 1.35 : (num("brightness") / 100) * daylight;
  const filter = `brightness(${light.toFixed(2)})${on("moonlight") ? " hue-rotate(-25deg) saturate(0.6) contrast(1.1)" : ""}${on("noFog") ? " contrast(1.08) saturate(1.1)" : ""}`;
  const phase = hour >= 5 && hour <= 7 ? "Dawn" : hour >= 8 && hour <= 16 ? "Day" : hour >= 17 && hour <= 19 ? "Dusk" : "Night";
  const weather = num("weather");

  // Player ESP geometry
  const mates = num("espClanmates");
  const players = PLAYERS.map((p) => {
    const ph = (p.h / 100) * h;
    const pw = ph * 0.42;
    const footX = (p.x / 100) * w;
    const footY = (p.y / 100) * h;
    const top = footY - ph;
    const aimY = top + ph * (BONES[num("aimBone")] ?? 0.09);
    return { ...p, ph, pw, footX, footY, top, left: footX - pw / 2, aimY, screen: Math.hypot(footX - w / 2, aimY - h / 2) };
  });
  const espVisible = players.filter((p) => on("espPlayers") && p.dist <= num("espMaxDist") && !(p.mate && mates === 2));

  // Aimbot target
  const fovR = num("aimFov");
  const candidates = players.filter(
    (p) => !(p.mate && on("aimIgnoreClan")) && p.dist <= num("aimMaxDist") && !(p.hidden && on("aimVisible")) && p.screen <= fovR,
  );
  const priority = num("aimPriority");
  const target = on("aimbot")
    ? [...candidates].sort((a, b) => (priority === 1 ? a.hp - b.hp : priority === 2 ? a.dist - b.dist : a.screen - b.screen))[0]
    : undefined;

  const snapOrigin = num("snapOrigin");
  const originY = snapOrigin === 0 ? h : snapOrigin === 1 ? h / 2 : 0;
  const boxStyle = num("espBoxStyle");

  const entities = ENTITIES.filter((e) => {
    if (e.dist > num("espWorldDist")) return false;
    if (e.kind === "animal") return on("espAnimals");
    if (e.kind === "predator") return on("espAnimals");
    if (e.kind === "resource") return on("espResources") && (num("espResourceType") === 0 || num("espResourceType") === e.type);
    if (e.kind === "container") return on("espContainers");
    if (e.kind === "dropped") return on("espDropped");
    return on("espShrines");
  });

  const activeMods = allOptions().filter((o) => o.kind === "toggle" && !ARRAY_SKIP.has(o.id) && values[o.id] === true);
  const crosshair = num("crosshair");
  const streamProof = on("streamProof");

  return (
    <div ref={ref} className="relative isolate h-full min-h-[360px] overflow-hidden rounded-2xl border border-border">
      <img
        src={valley.url}
        alt="Misty medieval valley with a stone keep and timber homesteads at dusk"
        width={1672}
        height={940}
        className="absolute inset-0 h-full w-full object-cover transition-all duration-700 ease-smooth"
        style={{ transform: `scale(${1 + (120 - num("fov")) / 180})`, filter }}
      />
      <div className="absolute inset-0 bg-scene-fade" />
      {weather === 2 && <div className="pointer-events-none absolute inset-0 animate-rain bg-rain" />}
      {weather === 3 && !on("noFog") && <div className="pointer-events-none absolute inset-0 bg-fog" />}

      {on("plotBorders") && (
        <div className="absolute left-[46%] top-[46%] h-[22%] w-[30%] rounded-md border border-dashed border-primary bg-primary/10">
          <span className="hud absolute -top-7 left-0 px-2 py-0.5 text-[10px] text-primary">
            Homestead Plot 14{on("decayTimers") && <span className="text-muted-foreground"> · decays in 6d 4h</span>}
          </span>
        </div>
      )}

      {/* Players, boxes, lines */}
      {w > 0 && (
        <svg className="pointer-events-none absolute inset-0" width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
          {players.map((p) => (
            <g key={p.name} transform={`translate(${p.left} ${p.top}) scale(${p.pw / 42} ${p.ph / 100})`} className="fill-background/75">
              <circle cx="21" cy="9" r="7" />
              <path d="M13 18h16l5 30h-4l-3-18v20l3 48h-7l-2-34-2 34h-7l3-48V30l-3 18H8z" />
            </g>
          ))}

          {on("espSnaplines") &&
            espVisible.map((p) => (
              <line
                key={`s-${p.name}`}
                x1={w / 2}
                y1={originY}
                x2={p.footX}
                y2={snapOrigin === 0 ? p.footY : snapOrigin === 1 ? p.top + p.ph / 2 : p.top}
                className={espColor(p, mates, num("espColor"))}
                stroke="currentColor"
                strokeOpacity={0.55}
                strokeWidth={1}
              />
            ))}

          {espVisible.map((p) => {
            const color = espColor(p, mates, num("espColor"));
            const locked = target?.name === p.name;
            return (
              <g key={`b-${p.name}`} className={cn(locked ? "text-primary-glow" : color, on("espGlow") && "drop-shadow-[0_0_4px_currentColor]")}>
                {boxStyle === 0 && <Corners x={p.left} y={p.top} w={p.pw} h={p.ph} />}
                {(boxStyle === 1 || boxStyle === 2) && (
                  <rect
                    x={p.left}
                    y={p.top}
                    width={p.pw}
                    height={p.ph}
                    fill="currentColor"
                    fillOpacity={boxStyle === 2 ? 0.14 : 0}
                    stroke="currentColor"
                    strokeWidth={1.25}
                  />
                )}
                {on("espHealth") && (
                  <>
                    <rect x={p.left - 5} y={p.top} width={2.5} height={p.ph} className="fill-background/70" />
                    <rect
                      x={p.left - 5}
                      y={p.top + p.ph * (1 - p.hp / 100)}
                      width={2.5}
                      height={(p.ph * p.hp) / 100}
                      className={p.hp > 60 ? "fill-success" : p.hp > 30 ? "fill-warning" : "fill-destructive"}
                    />
                  </>
                )}
                {on("espSkeleton") && (
                  <g transform={`translate(${p.left} ${p.top}) scale(${p.pw / 42} ${p.ph / 100})`} stroke="currentColor" strokeWidth={1.25} fill="none">
                    <path vectorEffect="non-scaling-stroke" d="M21 9V48M12 21h18M12 21l-3 25M30 21l3 25M21 48l-6 50M21 48l6 50" />
                  </g>
                )}
                {on("espHeadDot") && <circle cx={p.footX} cy={p.top + p.ph * 0.09} r={Math.max(2, p.pw * 0.12)} fill="currentColor" />}
              </g>
            );
          })}

          {on("aimFovCircle") && <circle cx={w / 2} cy={h / 2} r={fovR} fill="none" stroke="currentColor" strokeOpacity={0.5} className="text-foreground" />}

          {target && (
            <g className="text-primary-glow">
              {on("aimLine") && (
                <line x1={w / 2} y1={h / 2} x2={target.footX} y2={target.aimY} stroke="currentColor" strokeWidth={1.25} strokeDasharray={on("silentAim") ? "4 4" : undefined} />
              )}
              <circle cx={target.footX} cy={target.aimY} r={5} fill="none" stroke="currentColor" strokeWidth={1.5} />
              {on("triggerbot") && on("hitMarkers") && (
                <path
                  d={`M${target.footX - 9} ${target.aimY - 9}l5 5M${target.footX + 9} ${target.aimY - 9}l-5 5M${target.footX - 9} ${target.aimY + 9}l5 -5M${target.footX + 9} ${target.aimY + 9}l-5 -5`}
                  stroke="currentColor"
                  strokeWidth={2}
                  className="text-foreground"
                />
              )}
            </g>
          )}
        </svg>
      )}

      {/* Player labels */}
      {espVisible.map((p) => {
        const locked = target?.name === p.name;
        return (
          <div key={`l-${p.name}`} className="pointer-events-none absolute text-center" style={{ left: p.footX, top: p.top, transform: "translate(-50%, -100%)" }}>
            {locked && <p className="mb-0.5 font-mono text-[9px] font-bold tracking-[0.2em] text-primary-glow">LOCKED</p>}
            {(on("espNames") || on("espClan")) && (
              <p className="whitespace-nowrap pb-1 text-[11px] font-semibold leading-none drop-shadow">
                {on("espClan") && <span className={p.mate ? "text-success" : "text-primary"}>[{p.clan}] </span>}
                {on("espNames") && p.name}
              </p>
            )}
          </div>
        );
      })}
      {espVisible.map((p) => (
        <div key={`d-${p.name}`} className="pointer-events-none absolute whitespace-nowrap text-center font-mono text-[10px] leading-tight drop-shadow" style={{ left: p.footX, top: p.footY + 3, transform: "translateX(-50%)" }}>
          {on("espDistance") && <p>{p.dist}m</p>}
          {on("espWeapon") && <p className="text-muted-foreground">{p.weapon}</p>}
        </div>
      ))}
      {target && on("triggerbot") && on("damageNumbers") && (
        <span className="pointer-events-none absolute animate-float-up font-mono text-sm font-bold text-warning drop-shadow" style={{ left: target.footX + 12, top: target.aimY - 16 }}>
          -18
        </span>
      )}

      {/* World entities */}
      {entities.map((e) => (
        <div key={e.name} className={cn("pointer-events-none absolute flex items-center gap-1.5", ENTITY_COLORS[e.kind])} style={{ left: `${e.x}%`, top: `${e.y}%` }}>
          <span className="size-2 rotate-45 border border-current bg-current/30" />
          {on("espLabels") && (
            <span className="whitespace-nowrap text-[10px] font-medium drop-shadow">
              {e.name} <span className="font-mono text-muted-foreground">{e.dist}m</span>
            </span>
          )}
        </div>
      ))}

      <div className="pointer-events-none absolute inset-0 p-3 sm:p-5">
        {/* Top HUD */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex flex-col gap-2">
            <div className="hud flex items-center gap-2.5 p-2 pr-3.5">
              <div className="grid size-9 place-items-center rounded-md bg-surface-raised text-xs font-bold text-primary">AV</div>
              <div>
                <p className="text-[13px] font-semibold leading-tight">Aldric Vane</p>
                <div className="mt-1 flex items-center gap-2">
                  <span className="font-mono text-[10px] text-muted-foreground">Blacksmithing 42</span>
                  <div className="h-1 w-14 overflow-hidden rounded-full bg-input">
                    <div className="h-full w-3/5 rounded-full bg-primary" />
                  </div>
                </div>
              </div>
            </div>
            {streamProof && (
              <div className="hud flex w-fit items-center gap-1.5 px-2.5 py-1 font-mono text-[10px] text-success">
                <EyeOff className="size-3" /> stream proof · hidden from capture
              </div>
            )}
            {on("watermark") && !streamProof && (
              <div className="hud flex w-fit items-center gap-2 border-l-2 border-l-primary px-2.5 py-1 font-mono text-[10px] text-muted-foreground">
                <span className="font-semibold text-foreground">aurelis</span>| pax dei | {String(hour).padStart(2, "0")}:00
              </div>
            )}
          </div>

          {on("compass") && (
            <div className="hud hidden items-center gap-3 px-4 py-1.5 font-mono text-[11px] lg:flex">
              {COMPASS.map((c, i) => (
                <span key={i} className={c === "N" ? "font-bold text-primary" : "text-muted-foreground"}>
                  {c}
                </span>
              ))}
            </div>
          )}

          <div className="flex flex-col items-end gap-2">
            <div className="flex items-start gap-2">
              <div className="hud hidden px-3 py-1.5 text-right sm:block">
                <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Kerys · Day 12</p>
                <p className="font-mono text-xs">
                  {String(hour).padStart(2, "0")}:00 <span className="text-muted-foreground">{phase}</span>
                </p>
              </div>
              <Radar values={values} />
            </div>
            {on("arrayList") && !streamProof && activeMods.length > 0 && (
              <ul className="hidden flex-col items-end gap-px sm:flex">
                {activeMods.slice(0, 10).map((o) => (
                  <li key={o.id} className="border-r-2 border-r-primary bg-chrome/70 px-2 py-0.5 text-[11px] font-medium backdrop-blur">
                    {o.label}
                  </li>
                ))}
                {activeMods.length > 10 && <li className="px-2 text-[10px] text-muted-foreground">+{activeMods.length - 10} more</li>}
              </ul>
            )}
          </div>
        </div>

        {/* Crosshair */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-primary drop-shadow">
          {crosshair === 0 && <Target className="size-6" strokeWidth={1.5} />}
          {crosshair === 1 && <span className="block size-1.5 rounded-full bg-primary" />}
          {crosshair === 2 && <Plus className="size-5" strokeWidth={1.5} />}
          {crosshair === 3 && <Circle className="size-4" strokeWidth={1.5} />}
        </div>

        {on("nameplates") && (
          <p className="absolute left-1/2 top-[70%] -translate-x-1/2 whitespace-nowrap text-center text-[11px] font-semibold drop-shadow">
            Aldric Vane <span className="text-primary">&lt;Ravenmoor&gt;</span>
          </p>
        )}

        {!menuOpen && (
          <div className="hud absolute left-1/2 top-[58%] -translate-x-1/2 whitespace-nowrap px-3 py-1.5 text-xs">
            Press <span className="kbd mx-1">M</span> to open Aurelis
          </div>
        )}

        {/* Bottom HUD */}
        <div className="absolute inset-x-3 bottom-3 flex items-end justify-between gap-3 sm:inset-x-5 sm:bottom-5">
          <div className="hud w-40 space-y-2 p-2.5 sm:w-48">
            <Bar icon={<Heart className="size-3.5" />} label="86" pct={86} tone="health" />
            <Bar icon={<Zap className="size-3.5" />} label={on("infiniteStamina") ? "∞" : "64"} pct={on("infiniteStamina") ? 100 : 64} tone="stamina" />
          </div>

          <div className="hud hidden gap-1 p-1 xl:flex">
            {HOTBAR.map(({ icon: Icon, label, key }, i) => (
              <div
                key={key}
                title={label}
                className={cn(
                  "relative grid size-10 place-items-center rounded-md border",
                  i === 0 ? "border-primary bg-accent text-primary" : "border-transparent bg-surface/70 text-muted-foreground",
                )}
              >
                <Icon className="size-[18px]" />
                <span className="absolute left-1 top-0.5 font-mono text-[9px] text-muted-foreground">{key}</span>
              </div>
            ))}
          </div>

          <div className="hud px-3 py-2 text-right">
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Iron Longsword</p>
            <p className="font-mono text-lg font-semibold leading-tight">
              {on("noToolWear") ? 100 : 78}
              <span className="text-xs text-muted-foreground">%</span>
            </p>
            {on("durabilityWarn") && !on("noToolWear") && <p className="text-[10px] text-warning">Repair soon</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

function espColor(p: { mate: boolean }, mates: number, colorIdx: number): string {
  if (p.mate && mates === 0) return "text-success";
  return ESP_COLORS[colorIdx] ?? "text-primary";
}

function Corners({ x, y, w, h }: { x: number; y: number; w: number; h: number }) {
  const l = Math.min(w, h) * 0.3;
  const d = `M${x} ${y + l}V${y}H${x + l}M${x + w - l} ${y}H${x + w}V${y + l}M${x + w} ${y + h - l}V${y + h}H${x + w - l}M${x + l} ${y + h}H${x}V${y + h - l}`;
  return <path d={d} fill="none" stroke="currentColor" strokeWidth={1.5} />;
}

function Radar({ values }: { values: MenuValues }) {
  const on = (id: string) => Boolean(values[id]);
  const zoom = Number(values["minimapZoom"] ?? 2);
  return (
    <div className="relative size-20 overflow-hidden rounded-full border border-border bg-chrome/80 backdrop-blur sm:size-24">
      <div className="absolute inset-0 animate-sweep bg-radar" />
      <div className="absolute inset-0 transition-transform duration-500 ease-smooth" style={{ transform: `scale(${0.7 + zoom * 0.15})` }}>
        <div className="absolute inset-3 rounded-full border border-border" />
        <div className="absolute inset-6 rounded-full border border-border" />
        {on("clanMembers") && <span className="absolute right-[26%] top-[60%] size-1.5 rounded-full bg-success" />}
        {on("radarEnemies") && (
          <>
            <span className="absolute left-[28%] top-[36%] size-1.5 rounded-full bg-destructive" />
            <span className="absolute left-[56%] top-[28%] size-1.5 rounded-full bg-destructive" />
          </>
        )}
        {on("espRadar") && on("espAnimals") && <span className="absolute bottom-[26%] left-[40%] size-1.5 rounded-full bg-warning" />}
      </div>
      <span className="absolute left-1/2 top-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary" />
    </div>
  );
}

function Bar({ icon, label, pct, tone }: { icon: React.ReactNode; label: string; pct: number; tone: "health" | "stamina" }) {
  return (
    <div className="flex items-center gap-2">
      <span className={tone === "health" ? "text-destructive" : "text-primary"}>{icon}</span>
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-input">
        <div className={cn("h-full rounded-full transition-all duration-500", tone === "health" ? "bg-destructive" : "bg-primary")} style={{ width: `${pct}%` }} />
      </div>
      <span className="w-6 text-right font-mono text-xs">{label}</span>
    </div>
  );
}
