import { useEffect, useState } from "react";
import { Menu, OctagonX, Users, Wifi } from "lucide-react";

import { Button } from "@/components/ui/button";

export function AppHeader({ menuOpen, onToggleMenu, onPanic, panicKey }: { menuOpen: boolean; onToggleMenu: () => void; onPanic: () => void; panicKey: string }) {
  return (
    <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border bg-gradient-header px-4">
      <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-gradient-primary text-sm font-bold text-primary-foreground shadow-glow">
        A
      </span>
      <div className="flex min-w-0 flex-1 items-baseline gap-3">
        <h1 className="text-base font-bold uppercase tracking-[0.24em]">Aurelis</h1>
        <p className="hidden truncate text-xs text-muted-foreground sm:block">Pax Dei · Kerys · Homestead Plot 14</p>
      </div>

      <span className="hidden h-8 items-center gap-2 rounded-lg border border-border bg-surface px-3 font-mono text-xs md:flex">
        <Users className="size-3.5 text-primary" />
        Ravenmoor 8/20
      </span>
      <Button variant="destructive" size="sm" onClick={onPanic} title={`Panic (${panicKey})`}>
        <OctagonX />
        <span className="hidden sm:inline">Panic</span>
        <span className="kbd hidden h-5 border-destructive-foreground/30 bg-transparent text-destructive-foreground md:inline-flex">{panicKey}</span>
      </Button>
      <Button variant={menuOpen ? "outline" : "glow"} size="sm" onClick={onToggleMenu}>
        <Menu />
        <span className="hidden sm:inline">{menuOpen ? "Hide menu" : "Open menu"}</span>
      </Button>
    </header>
  );
}

const HINTS: [string, string][] = [
  ["↑↓", "Scroll"],
  ["←→", "Adjust"],
  ["Q/E", "Tabs"],
  ["Enter", "Select"],
  ["M", "Menu"],
  ["/", "Search"],
];

export function StatusFooter({ showHints }: { showHints: boolean }) {
  const [fps, setFps] = useState(60);
  const [ping, setPing] = useState(42);

  useEffect(() => {
    const t = setInterval(() => {
      setFps(58 + Math.round(Math.random() * 4));
      setPing(38 + Math.round(Math.random() * 14));
    }, 1500);
    return () => clearInterval(t);
  }, []);

  return (
    <footer className="flex h-10 shrink-0 items-center justify-between gap-6 border-t border-border bg-chrome px-4 text-xs text-muted-foreground">
      <nav aria-label="Controls" className="hidden items-center gap-4 md:flex">
        {showHints &&
          HINTS.map(([key, label]) => (
            <span key={label} className="flex items-center gap-1.5">
              <span className="kbd">{key}</span>
              {label}
            </span>
          ))}
      </nav>
      <div className="flex flex-1 items-center justify-between gap-5 font-mono tabular-nums md:flex-none md:justify-end">
        <span className="flex items-center gap-2">
          <span className="size-2 animate-pulse-dot rounded-full bg-success" />
          Connected · EU
        </span>
        <span className="flex w-14 items-center gap-1.5">
          <Wifi className="size-3.5 text-primary" />
          {ping}ms
        </span>
        <span className="w-12">
          <span className="text-foreground">{fps}</span> FPS
        </span>
        <span className="hidden sm:inline">v1.0</span>
      </div>
    </footer>
  );
}
