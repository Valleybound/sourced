import {
  Crosshair, Footprints, Hammer, House, Layers, Map as MapIcon, Pickaxe, ScanEye, Settings, Sun, Swords, TreePine, User,
  type LucideIcon,
} from "lucide-react";

type Base = { id: string; label: string; hint?: string };
export type ToggleOption = Base & { kind: "toggle"; def: boolean };
export type SliderOption = Base & {
  kind: "slider";
  min: number;
  max: number;
  step: number;
  unit?: string;
  def: number;
};
/** A list of named choices; the stored value is the index of the picked choice. */
export type ChoiceOption = Base & { kind: "choice"; choices: readonly string[]; def: number };
export type ActionOption = Base & { kind: "action"; message: string; preset?: PresetId };
export type MenuOption = ToggleOption | SliderOption | ChoiceOption | ActionOption;

export type MenuCategory = { id: string; label: string; icon: LucideIcon; options: MenuOption[] };
export type MenuValues = Record<string, boolean | number>;

export type PresetId = "legit" | "rage" | "gatherer" | "builder" | "defaults";

export const THEMES = ["pink", "rose", "lilac", "crimson"] as const;

export const MENU: MenuCategory[] = [
  {
    id: "aim",
    icon: Crosshair,
    label: "Aimbot",
    options: [
      { id: "aimbot", label: "Aimbot", kind: "toggle", def: false, hint: "Locks onto the best target inside the FOV circle" },
      { id: "silentAim", label: "Silent Aim", kind: "toggle", def: false, hint: "Arrows curve to the target without moving the camera" },
      { id: "aimKey", label: "Aim Key", kind: "choice", choices: ["Right Mouse", "Left Mouse", "Shift", "Mouse 4", "Always On"], def: 0 },
      { id: "aimBone", label: "Target Bone", kind: "choice", choices: ["Head", "Neck", "Chest", "Pelvis"], def: 0 },
      { id: "aimPriority", label: "Target Priority", kind: "choice", choices: ["Crosshair", "Lowest Health", "Nearest"], def: 0 },
      { id: "aimFovCircle", label: "Draw FOV Circle", kind: "toggle", def: true },
      { id: "aimFov", label: "FOV Radius", kind: "slider", min: 40, max: 320, step: 10, unit: "px", def: 140 },
      { id: "aimSmooth", label: "Smoothing", kind: "slider", min: 1, max: 20, step: 1, def: 6, hint: "1 snaps instantly, 20 glides slowly" },
      { id: "aimMaxDist", label: "Max Target Distance", kind: "slider", min: 10, max: 300, step: 10, unit: "m", def: 150 },
      { id: "aimPrediction", label: "Arrow Prediction", kind: "toggle", def: false, hint: "Leads moving targets for bow shots" },
      { id: "aimVisible", label: "Visibility Check", kind: "toggle", def: true },
      { id: "aimIgnoreClan", label: "Ignore Clan Members", kind: "toggle", def: true },
      { id: "aimLine", label: "Draw Target Line", kind: "toggle", def: true },
    ],
  },
  {
    id: "combat",
    icon: Swords,
    label: "Combat",
    options: [
      { id: "triggerbot", label: "Triggerbot", kind: "toggle", def: false, hint: "Swings or looses automatically when a target is locked" },
      { id: "triggerDelay", label: "Trigger Delay", kind: "slider", min: 0, max: 300, step: 10, unit: "ms", def: 80 },
      { id: "autoParry", label: "Auto Parry", kind: "toggle", def: false },
      { id: "autoBlock", label: "Auto Block", kind: "toggle", def: false },
      { id: "noSwingStamina", label: "No Swing Stamina Cost", kind: "toggle", def: false },
      { id: "meleeReach", label: "Melee Reach", kind: "slider", min: 1, max: 2, step: 0.1, unit: "x", def: 1 },
      { id: "bowDraw", label: "Bow Draw Speed", kind: "slider", min: 1, max: 3, step: 0.25, unit: "x", def: 1 },
      { id: "noSway", label: "No Bow Sway", kind: "toggle", def: false },
      { id: "hitMarkers", label: "Hit Markers", kind: "toggle", def: true },
      { id: "damageNumbers", label: "Damage Numbers", kind: "toggle", def: true },
      { id: "hitSound", label: "Hit Sound", kind: "choice", choices: ["Off", "Bell", "Thud", "Chime"], def: 1 },
      { id: "quickHeal", label: "Quick Heal", kind: "action", message: "Drank a Healing Draught (+40 HP)" },
    ],
  },
  {
    id: "espPlayers",
    icon: ScanEye,
    label: "Player ESP",
    options: [
      { id: "espPlayers", label: "Enable Player ESP", kind: "toggle", def: true },
      { id: "espBoxStyle", label: "Box Style", kind: "choice", choices: ["Corners", "2D Box", "Filled", "Off"], def: 0 },
      { id: "espNames", label: "Names", kind: "toggle", def: true },
      { id: "espClan", label: "Clan Tags", kind: "toggle", def: true },
      { id: "espDistance", label: "Distance", kind: "toggle", def: true },
      { id: "espHealth", label: "Health Bars", kind: "toggle", def: true },
      { id: "espWeapon", label: "Held Weapon", kind: "toggle", def: false },
      { id: "espSkeleton", label: "Skeleton", kind: "toggle", def: false },
      { id: "espHeadDot", label: "Head Dot", kind: "toggle", def: false },
      { id: "espSnaplines", label: "Snaplines", kind: "toggle", def: false },
      { id: "snapOrigin", label: "Snapline Origin", kind: "choice", choices: ["Bottom", "Center", "Top"], def: 0 },
      { id: "espGlow", label: "Glow Outline", kind: "toggle", def: false },
      { id: "espClanmates", label: "Clanmates", kind: "choice", choices: ["Friendly Color", "Same Color", "Hide"], def: 0 },
      { id: "espColor", label: "ESP Color", kind: "choice", choices: ["Accent", "Gold", "Mint", "Crimson"], def: 0 },
      { id: "espMaxDist", label: "Max Distance", kind: "slider", min: 25, max: 500, step: 25, unit: "m", def: 300 },
    ],
  },
  {
    id: "espWorld",
    icon: TreePine,
    label: "World ESP",
    options: [
      { id: "espAnimals", label: "Wildlife", kind: "toggle", def: true },
      { id: "espPredators", label: "Highlight Predators", kind: "toggle", def: true, hint: "Wolves and bears show in red" },
      { id: "espResources", label: "Resource Nodes", kind: "toggle", def: true },
      { id: "espResourceType", label: "Resource Filter", kind: "choice", choices: ["All", "Ore", "Wood", "Fibre", "Herbs"], def: 0 },
      { id: "espContainers", label: "Chests & Containers", kind: "toggle", def: false },
      { id: "espDropped", label: "Dropped Items", kind: "toggle", def: false },
      { id: "espShrines", label: "Shrines & Altars", kind: "toggle", def: false },
      { id: "espLabels", label: "Entity Labels", kind: "toggle", def: true },
      { id: "espWorldDist", label: "Max Distance", kind: "slider", min: 25, max: 500, step: 25, unit: "m", def: 200 },
      { id: "espRadar", label: "Show on Radar", kind: "toggle", def: true },
    ],
  },
  {
    id: "player",
    icon: User,
    label: "Player",
    options: [
      { id: "infiniteStamina", label: "Infinite Stamina", kind: "toggle", def: false },
      { id: "noHunger", label: "No Hunger & Thirst", kind: "toggle", def: false },
      { id: "noFallDamage", label: "No Fall Damage", kind: "toggle", def: true },
      { id: "noWeight", label: "No Weight Limit", kind: "toggle", def: false },
      { id: "autoHeal", label: "Auto Heal Below 30%", kind: "toggle", def: false },
      { id: "antiAfk", label: "Anti-AFK", kind: "toggle", def: true },
      { id: "freeCam", label: "Free Camera", kind: "toggle", def: false },
      { id: "nameplates", label: "Own Nameplate", kind: "toggle", def: true },
      { id: "restoreHealth", label: "Restore Health", kind: "action", message: "Health restored to 100" },
      { id: "teleport", label: "Teleport to Waypoint", kind: "action", message: "Teleported to the river crossing" },
    ],
  },
  {
    id: "movement",
    icon: Footprints,
    label: "Movement",
    options: [
      { id: "speed", label: "Walk Speed", kind: "slider", min: 1, max: 3, step: 0.25, unit: "x", def: 1 },
      { id: "sprintSpeed", label: "Sprint Speed", kind: "slider", min: 1, max: 3, step: 0.25, unit: "x", def: 1 },
      { id: "jump", label: "Jump Height", kind: "slider", min: 1, max: 5, step: 0.5, unit: "x", def: 1 },
      { id: "swimSpeed", label: "Swim Speed", kind: "slider", min: 1, max: 3, step: 0.25, unit: "x", def: 1 },
      { id: "fly", label: "Fly Mode", kind: "toggle", def: false },
      { id: "flySpeed", label: "Fly Speed", kind: "slider", min: 1, max: 10, step: 1, unit: "x", def: 3 },
      { id: "noclip", label: "No Clip", kind: "toggle", def: false },
      { id: "climbAnything", label: "Climb Any Surface", kind: "toggle", def: false },
      { id: "autoRun", label: "Auto Run", kind: "toggle", def: false },
      { id: "autoJump", label: "Auto Jump", kind: "toggle", def: false },
    ],
  },
  {
    id: "gathering",
    icon: Pickaxe,
    label: "Gathering",
    options: [
      { id: "autoLoot", label: "Auto-Loot", kind: "toggle", def: false },
      { id: "autoGather", label: "Auto Gather Nearby", kind: "toggle", def: false },
      { id: "gatherSpeed", label: "Gather Speed", kind: "slider", min: 1, max: 5, step: 0.5, unit: "x", def: 1 },
      { id: "yield", label: "Yield Multiplier", kind: "slider", min: 1, max: 5, step: 0.5, unit: "x", def: 1 },
      { id: "noToolWear", label: "No Tool Wear", kind: "toggle", def: false },
      { id: "durabilityWarn", label: "Tool Durability Alerts", kind: "toggle", def: true },
      { id: "sortInventory", label: "Sort Inventory", kind: "action", message: "Inventory sorted by type" },
      { id: "depositAll", label: "Deposit All to Chest", kind: "action", message: "38 items moved to the homestead chest" },
    ],
  },
  {
    id: "crafting",
    icon: Hammer,
    label: "Crafting",
    options: [
      { id: "instantCraft", label: "Instant Craft", kind: "toggle", def: false },
      { id: "queueSize", label: "Craft Queue Size", kind: "slider", min: 1, max: 25, step: 1, def: 5 },
      { id: "craftQuality", label: "Craft Quality", kind: "choice", choices: ["Common", "Fine", "Superior", "Masterwork"], def: 0 },
      { id: "revealRecipes", label: "Reveal All Recipes", kind: "toggle", def: false },
      { id: "recipeTips", label: "Recipe Tooltips", kind: "toggle", def: true },
      { id: "repairAll", label: "Repair All Gear", kind: "action", message: "All gear repaired to 100%" },
      { id: "craftIngots", label: "Smelt Iron Ingots", kind: "action", message: "10× Iron Ingot added to the queue" },
    ],
  },
  {
    id: "building",
    icon: House,
    label: "Building",
    options: [
      { id: "snapGrid", label: "Snap to Grid", kind: "toggle", def: true },
      { id: "gridSize", label: "Grid Size", kind: "slider", min: 0.25, max: 2, step: 0.25, unit: "m", def: 0.5 },
      { id: "rotationStep", label: "Rotation Step", kind: "slider", min: 5, max: 90, step: 5, unit: "°", def: 15 },
      { id: "ignoreCollision", label: "Ignore Collision", kind: "toggle", def: false },
      { id: "plotBorders", label: "Show Plot Borders", kind: "toggle", def: false },
      { id: "decayTimers", label: "Show Decay Timers", kind: "toggle", def: false },
      { id: "blueprint", label: "Place Blueprint", kind: "action", message: "Timber cottage blueprint placed" },
    ],
  },
  {
    id: "visuals",
    icon: Sun,
    label: "Visuals",
    options: [
      { id: "fov", label: "Field of View", kind: "slider", min: 65, max: 120, step: 1, unit: "°", def: 90 },
      { id: "brightness", label: "Brightness", kind: "slider", min: 40, max: 160, step: 5, unit: "%", def: 100 },
      { id: "fullbright", label: "Fullbright", kind: "toggle", def: false },
      { id: "timeOfDay", label: "Time of Day", kind: "slider", min: 0, max: 23, step: 1, unit: ":00", def: 18 },
      { id: "weather", label: "Weather", kind: "choice", choices: ["Live", "Clear", "Rain", "Fog"], def: 0 },
      { id: "noFog", label: "Remove Fog", kind: "toggle", def: false },
      { id: "moonlight", label: "Moonlight Filter", kind: "toggle", def: false },
      { id: "crosshair", label: "Crosshair", kind: "choice", choices: ["Reticle", "Dot", "Cross", "Circle", "Off"], def: 0 },
    ],
  },
  {
    id: "map",
    icon: MapIcon,
    label: "Map & Clan",
    options: [
      { id: "compass", label: "Show Compass", kind: "toggle", def: true },
      { id: "minimapZoom", label: "Minimap Zoom", kind: "slider", min: 1, max: 5, step: 0.5, unit: "x", def: 2 },
      { id: "radarEnemies", label: "Enemies on Radar", kind: "toggle", def: false },
      { id: "clanMembers", label: "Clan on Radar", kind: "toggle", def: true },
      { id: "revealMap", label: "Reveal Map", kind: "toggle", def: false },
      { id: "clanAlerts", label: "Clan Chat Alerts", kind: "toggle", def: true },
      { id: "waypoint", label: "Mark Waypoint", kind: "action", message: "Waypoint set at the river crossing" },
      { id: "invite", label: "Invite to Clan", kind: "action", message: "Invite sent to nearby traveller" },
    ],
  },
  {
    id: "configs",
    icon: Layers,
    label: "Configs",
    options: [
      { id: "loadLegit", label: "Load: Legit", kind: "action", preset: "legit", message: "Legit config loaded" },
      { id: "loadRage", label: "Load: Rage", kind: "action", preset: "rage", message: "Rage config loaded" },
      { id: "loadGatherer", label: "Load: Gatherer", kind: "action", preset: "gatherer", message: "Gatherer config loaded" },
      { id: "loadBuilder", label: "Load: Master Builder", kind: "action", preset: "builder", message: "Master Builder config loaded" },
      { id: "saveConfig", label: "Save Current Config", kind: "action", message: "Config saved to slot 1" },
      { id: "reset", label: "Disable All Mods", kind: "action", preset: "defaults", message: "All mods reset to default" },
    ],
  },
  {
    id: "settings",
    icon: Settings,
    label: "Settings",
    options: [
      { id: "menuTheme", label: "Menu Theme", kind: "choice", choices: ["Pink", "Rose", "Lilac", "Crimson"], def: 0 },
      { id: "menuOpacity", label: "Menu Opacity", kind: "slider", min: 60, max: 100, step: 5, unit: "%", def: 92 },
      { id: "menuSide", label: "Menu Position", kind: "choice", choices: ["Right", "Left"], def: 0 },
      { id: "watermark", label: "Watermark", kind: "toggle", def: true },
      { id: "arrayList", label: "Active Mods List", kind: "toggle", def: true, hint: "Lists switched-on mods along the edge of the game view" },
      { id: "notifications", label: "Notifications", kind: "toggle", def: true },
      { id: "keyHints", label: "Keybind Hints", kind: "toggle", def: true },
      { id: "streamProof", label: "Stream Proof", kind: "toggle", def: false, hint: "Hides the watermark, mods list and menu from screen capture" },
      { id: "panicKey", label: "Panic Key", kind: "choice", choices: ["End", "Delete", "Insert", "F10"], def: 0, hint: "Closes the menu and switches every mod off (or use the Panic button)" },
      { id: "autosave", label: "Remember Settings", kind: "toggle", def: true, hint: "Keeps your options after a page reload" },
    ],
  },
];

const ALL_OPTIONS = MENU.flatMap((c) => c.options);

export const DEFAULT_VALUES: MenuValues = Object.fromEntries(
  ALL_OPTIONS.flatMap((o) => (o.kind === "action" ? [] : [[o.id, o.def] as const])),
);

export const PRESETS: Record<Exclude<PresetId, "defaults">, MenuValues> = {
  legit: {
    aimbot: true, silentAim: false, aimSmooth: 12, aimFov: 90, aimFovCircle: false, aimLine: false,
    triggerbot: false, espPlayers: true, espBoxStyle: 0, espNames: true, espHealth: true,
    espSkeleton: false, espSnaplines: false, speed: 1, fly: false, noclip: false,
  },
  rage: {
    aimbot: true, silentAim: true, aimSmooth: 1, aimFov: 300, aimFovCircle: true, aimLine: true,
    aimMaxDist: 300, aimVisible: false, triggerbot: true, triggerDelay: 0, autoParry: true,
    espPlayers: true, espBoxStyle: 1, espSkeleton: true, espHeadDot: true, espSnaplines: true,
    espWeapon: true, espGlow: true, espMaxDist: 500, speed: 2.5, jump: 3, infiniteStamina: true,
  },
  gatherer: {
    aimbot: false, triggerbot: false, espResources: true, espResourceType: 0, espAnimals: true,
    espContainers: true, espDropped: true, autoLoot: true, autoGather: true, gatherSpeed: 4,
    yield: 3, noToolWear: true, noWeight: true, infiniteStamina: true,
  },
  builder: {
    aimbot: false, snapGrid: true, gridSize: 0.25, rotationStep: 5, plotBorders: true,
    ignoreCollision: true, decayTimers: true, freeCam: true, fly: true, fullbright: true,
  },
};

export const PANIC_KEYS = ["End", "Delete", "Insert", "F10"] as const;
const SETTINGS_IDS = new Set(MENU.find((c) => c.id === "settings")?.options.map((o) => o.id));

/** Panic: every mod switched off and sliders reset; menu settings (theme, keys…) are kept. */
export function panicValues(values: MenuValues): MenuValues {
  const next = { ...DEFAULT_VALUES };
  for (const o of ALL_OPTIONS) if (o.kind === "toggle") next[o.id] = false;
  for (const id of SETTINGS_IDS) if (id in values) next[id] = values[id]!;
  return next;
}

export function applyPreset(values: MenuValues, preset: PresetId): MenuValues {
  return preset === "defaults" ? { ...DEFAULT_VALUES } : { ...values, ...PRESETS[preset] };
}

/** Count the mods currently switched on. */
export function countActive(values: MenuValues): number {
  return ALL_OPTIONS.filter((o) => o.kind === "toggle" && values[o.id] === true).length;
}

export function allOptions(): MenuOption[] {
  return ALL_OPTIONS;
}

/** Move a selection index by `delta`, wrapping around both ends of a list. */
export function wrapIndex(index: number, delta: number, length: number): number {
  if (length <= 0) return 0;
  return (((index + delta) % length) + length) % length;
}

/** Step a slider value by whole steps, clamped to its range. */
export function stepSlider(option: SliderOption, value: number, direction: 1 | -1): number {
  const next = value + option.step * direction;
  const clamped = Math.min(option.max, Math.max(option.min, next));
  return Math.round(clamped * 100) / 100;
}
