import { describe, expect, it } from "vitest";
import { countActive as countOn } from "./menu-data";

import { allOptions, applyPreset, panicValues, DEFAULT_VALUES, PRESETS, stepSlider, wrapIndex, type SliderOption } from "./menu-data";

const fov: SliderOption = { id: "fov", label: "FOV", kind: "slider", min: 65, max: 120, step: 1, def: 90 };

describe("menu navigation", () => {
  it("wraps from the last option back to the first", () => {
    expect(wrapIndex(5, 1, 6)).toBe(0);
  });
  it("wraps from the first option up to the last", () => {
    expect(wrapIndex(0, -1, 6)).toBe(5);
  });
  it("never pushes a slider past its maximum", () => {
    expect(stepSlider(fov, 120, 1)).toBe(120);
  });
  it("never pushes a slider below its minimum", () => {
    expect(stepSlider(fov, 65, -1)).toBe(65);
  });
});

describe("menu data", () => {
  it("gives every option a unique id", () => {
    const ids = allOptions().map((o) => o.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
  it("starts every slider inside its range", () => {
    for (const o of allOptions()) {
      if (o.kind === "slider") {
        expect(o.def, o.id).toBeGreaterThanOrEqual(o.min);
        expect(o.def, o.id).toBeLessThanOrEqual(o.max);
      }
    }
  });
  it("starts every choice on a real entry", () => {
    for (const o of allOptions()) {
      if (o.kind === "choice") expect(o.choices[o.def], o.id).toBeDefined();
    }
  });
  it("only lets configs change options that exist", () => {
    for (const preset of Object.values(PRESETS)) {
      for (const id of Object.keys(preset)) expect(DEFAULT_VALUES, id).toHaveProperty(id);
    }
  });
  it("panic switches every mod off", () => {
    const raged = applyPreset(DEFAULT_VALUES, "rage");
    const settingsOn = ["watermark", "arrayList", "notifications", "keyHints", "autosave"].length;
    expect(countOn(panicValues(raged))).toBe(settingsOn);
    expect(panicValues(raged)["espPlayers"]).toBe(false);
    expect(panicValues(raged)["aimbot"]).toBe(false);
  });
  it("panic keeps the chosen menu theme", () => {
    expect(panicValues({ ...DEFAULT_VALUES, menuTheme: 2, aimbot: true })["menuTheme"]).toBe(2);
  });
  it("Disable All Mods turns the aimbot back off", () => {
    const raged = applyPreset(DEFAULT_VALUES, "rage");
    expect(raged["aimbot"]).toBe(true);
    expect(applyPreset(raged, "defaults")["aimbot"]).toBe(false);
  });
});
