import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, EyeOff, Search, X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { allOptions, countActive, MENU, stepSlider, wrapIndex, type MenuOption, type MenuValues, type PresetId } from "./menu-data";

type Props = {
  values: MenuValues;
  onChange: (id: string, value: boolean | number) => void;
  onPreset: (preset: PresetId) => void;
  open: boolean;
};

export function ModMenu({ values, onChange, onPreset, open }: Props) {
  const [catIndex, setCatIndex] = useState(0);
  const [selected, setSelected] = useState(0);
  const tabsRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState("");
  const q = query.trim().toLowerCase();

  const category = MENU[catIndex] ?? MENU[0]!;
  const options = q ? allOptions().filter((o) => o.label.toLowerCase().includes(q)) : category.options;
  const current = options[selected];
  const notify = values["notifications"] !== false;
  const opacity = Number(values["menuOpacity"] ?? 92);
  const activeIn = (c: (typeof MENU)[number]) => c.options.filter((o) => o.kind === "toggle" && values[o.id] === true).length;

  useEffect(() => {
    for (const el of [tabsRef.current, railRef.current]) {
      (el?.children[catIndex] as HTMLElement | undefined)?.scrollIntoView({ block: "nearest", inline: "nearest" });
    }
  }, [catIndex]);
  useEffect(() => {
    (listRef.current?.children[selected] as HTMLElement | undefined)?.scrollIntoView({ block: "nearest" });
  }, [selected, catIndex]);

  const pickCategory = useCallback((i: number) => {
    setQuery("");
    setCatIndex(i);
    setSelected(0);
  }, []);
  const switchCategory = useCallback((delta: number) => {
    setQuery("");
    setCatIndex((i) => wrapIndex(i, delta, MENU.length));
    setSelected(0);
  }, []);

  const cycleChoice = useCallback(
    (option: MenuOption, dir: 1 | -1) => {
      if (option.kind !== "choice") return;
      onChange(option.id, wrapIndex(Number(values[option.id] ?? option.def), dir, option.choices.length));
    },
    [values, onChange],
  );

  const activate = useCallback(
    (option: MenuOption) => {
      if (option.kind === "toggle") {
        const next = !values[option.id];
        onChange(option.id, next);
        if (notify) toast(`${option.label} ${next ? "enabled" : "disabled"}`);
      } else if (option.kind === "choice") {
        cycleChoice(option, 1);
      } else if (option.kind === "action") {
        if (option.preset) onPreset(option.preset);
        if (notify) toast.success(option.message);
      }
    },
    [values, onChange, onPreset, cycleChoice, notify],
  );

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest("[role=slider], input, textarea")) return;
      switch (e.key) {
        case "/":
          e.preventDefault();
          searchRef.current?.focus();
          break;
        case "ArrowDown":
          e.preventDefault();
          setSelected((i) => wrapIndex(i, 1, options.length));
          break;
        case "ArrowUp":
          e.preventDefault();
          setSelected((i) => wrapIndex(i, -1, options.length));
          break;
        case "ArrowRight":
        case "ArrowLeft": {
          e.preventDefault();
          const dir = e.key === "ArrowRight" ? 1 : -1;
          if (current?.kind === "slider") onChange(current.id, stepSlider(current, Number(values[current.id]), dir));
          else if (current?.kind === "choice") cycleChoice(current, dir);
          else switchCategory(dir);
          break;
        }
        case "q":
        case "Q":
          switchCategory(-1);
          break;
        case "e":
        case "E":
          switchCategory(1);
          break;
        case "Enter":
          if (current && target?.tagName !== "BUTTON") {
            e.preventDefault();
            activate(current);
          }
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, options, current, values, onChange, activate, switchCategory, cycleChoice]);

  return (
    <section
      aria-label="Aurelis menu"
      aria-hidden={!open}
      style={{ backgroundColor: `color-mix(in oklch, var(--chrome) ${opacity}%, transparent)` }}
      className={cn(
        "flex h-full w-full flex-col overflow-hidden rounded-2xl border border-border border-t-2 border-t-primary shadow-window backdrop-blur-xl transition-all duration-300 ease-smooth",
        open ? "translate-x-0 opacity-100" : "pointer-events-none translate-x-4 opacity-0",
      )}
    >
      {/* Title bar */}
      <header className="flex h-12 shrink-0 items-center gap-2.5 border-b border-border px-4">
        <span className="grid size-6 place-items-center rounded-md bg-primary text-xs font-bold text-primary-foreground">A</span>
        <h2 className="text-sm font-semibold uppercase tracking-[0.22em]">Aurelis</h2>
        <span className="font-mono text-[11px] text-muted-foreground">v1.0</span>
        {values["streamProof"] === true && (
          <span title="Hidden from screen capture" className="flex items-center gap-1 font-mono text-[10px] text-success">
            <EyeOff className="size-3" /> SP
          </span>
        )}
        <span className="ml-auto rounded-md border border-border px-2 py-0.5 font-mono text-[11px] text-muted-foreground">
          <span className="text-primary">{countActive(values)}</span> active
        </span>
      </header>

      {/* Search across every category */}
      <div className="flex h-10 shrink-0 items-center gap-2 border-b border-border px-4">
        <Search className="size-3.5 shrink-0 text-muted-foreground" />
        <input
          ref={searchRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setSelected(0);
          }}
          onKeyDown={(e) => {
            if (e.key === "Escape") {
              setQuery("");
              e.currentTarget.blur();
            } else if (e.key === "ArrowDown" || e.key === "Enter") {
              e.preventDefault();
              e.currentTarget.blur();
            }
          }}
          placeholder="Search options…"
          aria-label="Search options"
          className="min-w-0 flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
        />
        {query ? (
          <button aria-label="Clear search" onClick={() => setQuery("")} className="cursor-pointer text-muted-foreground hover:text-foreground">
            <X className="size-3.5" />
          </button>
        ) : (
          <span className="kbd h-5">/</span>
        )}
      </div>

      {/* Tabs (narrow screens) */}
      <div className="flex shrink-0 items-center gap-1 border-b border-border px-2 py-2 sm:hidden">
        <Button variant="ghost" size="icon-sm" aria-label="Previous category" onClick={() => switchCategory(-1)}>
          <ChevronLeft />
        </Button>
        <div ref={tabsRef} className="flex flex-1 gap-1 overflow-x-auto [scrollbar-width:none]">
          {MENU.map((c, i) => (
            <button
              key={c.id}
              onClick={() => pickCategory(i)}
              className={cn(
                "shrink-0 cursor-pointer rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                i === catIndex ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-surface-raised hover:text-foreground",
              )}
            >
              {c.label}
            </button>
          ))}
        </div>
        <Button variant="ghost" size="icon-sm" aria-label="Next category" onClick={() => switchCategory(1)}>
          <ChevronRight />
        </Button>
      </div>

      <div className="flex min-h-0 flex-1">
        {/* Category rail */}
        <nav
          ref={railRef}
          aria-label="Menu categories"
          className="scrollbar-thin hidden w-40 shrink-0 flex-col gap-0.5 overflow-y-auto border-r border-border p-2 sm:flex"
        >
          {MENU.map((c, i) => {
            const Icon = c.icon;
            const active = i === catIndex;
            return (
              <button
                key={c.id}
                onClick={() => pickCategory(i)}
                className={cn(
                  "relative flex h-8 shrink-0 cursor-pointer items-center gap-2.5 rounded-md px-2.5 text-left text-xs font-medium transition-colors",
                  active ? "bg-surface-raised text-foreground" : "text-muted-foreground hover:bg-surface hover:text-foreground",
                )}
              >
                <span className={cn("absolute inset-y-1.5 left-0 w-0.5 rounded-full bg-primary transition-opacity", active ? "opacity-100" : "opacity-0")} />
                <Icon className={cn("size-3.5 shrink-0", active && "text-primary")} />
                <span className="flex-1 truncate">{c.label}</span>
                <span className={cn("w-4 text-right font-mono text-[10px] tabular-nums", activeIn(c) ? "text-primary" : "text-muted-foreground/40")}>
                  {activeIn(c)}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Options */}
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex h-9 shrink-0 items-center justify-between px-4 text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground">
            <span>{q ? `Search · ${options.length} found` : category.label}</span>
            <span className="font-mono tabular-nums tracking-normal">
              {String(selected + 1).padStart(2, "0")} / {String(options.length).padStart(2, "0")}
            </span>
          </div>
          <ul
            ref={listRef}
            key={q ? "search" : category.id}
            className="scrollbar-thin flex max-h-[420px] flex-col gap-px overflow-y-auto px-2 pb-2 sm:max-h-none sm:flex-1"
          >
            {options.map((option, i) => (
              <li
                key={option.id}
                onMouseEnter={() => setSelected(i)}
                className={cn(
                  "relative flex h-9 shrink-0 items-center gap-3 rounded-md pl-3 pr-2 transition-colors duration-150",
                  i === selected ? "bg-surface-raised" : "hover:bg-surface",
                )}
              >
                <span
                  className={cn(
                    "absolute inset-y-2 left-0 w-0.5 rounded-full bg-primary transition-opacity duration-150",
                    i === selected ? "opacity-100" : "opacity-0",
                  )}
                />
                <OptionRow option={option} value={values[option.id]} onChange={onChange} onActivate={activate} onCycle={cycleChoice} />
              </li>
            ))}
            {options.length === 0 && <li className="px-3 py-6 text-center text-xs text-muted-foreground">No options match “{query}”</li>}
          </ul>
        </div>
      </div>

      <footer className="flex h-10 shrink-0 items-center gap-2 border-t border-border px-4 text-xs text-muted-foreground">
        <span className="min-w-0 flex-1 truncate">{current?.hint ?? current?.label}</span>
        <span className="shrink-0 font-mono text-[11px]">{hintFor(current)}</span>
      </footer>
    </section>
  );
}

function hintFor(option: MenuOption | undefined): string {
  if (!option) return "";
  if (option.kind === "slider") return "← → to adjust";
  if (option.kind === "choice") return "← → to change";
  if (option.kind === "action") return "Enter to run";
  return "Enter to toggle";
}

function OptionRow({
  option,
  value,
  onChange,
  onActivate,
  onCycle,
}: {
  option: MenuOption;
  value: boolean | number | undefined;
  onChange: (id: string, value: boolean | number) => void;
  onActivate: (option: MenuOption) => void;
  onCycle: (option: MenuOption, dir: 1 | -1) => void;
}) {
  return (
    <>
      <label htmlFor={option.id} className="min-w-0 flex-1 cursor-pointer truncate text-[13px]">
        {option.label}
      </label>
      <div className="flex w-[136px] shrink-0 items-center justify-end gap-2">
        <Control option={option} value={value} onChange={onChange} onActivate={onActivate} onCycle={onCycle} />
      </div>
    </>
  );
}

function Control({ option, value, onChange, onActivate, onCycle }: Parameters<typeof OptionRow>[0]) {
  if (option.kind === "toggle") {
    return <Switch id={option.id} checked={Boolean(value)} onCheckedChange={() => onActivate(option)} />;
  }

  if (option.kind === "slider") {
    const num = Number(value);
    return (
      <>
        <Slider
          id={option.id}
          aria-label={option.label}
          className="flex-1"
          min={option.min}
          max={option.max}
          step={option.step}
          value={[num]}
          onValueChange={([v]) => v !== undefined && onChange(option.id, v)}
        />
        <span className="w-11 text-right font-mono text-xs tabular-nums text-foreground">
          {num}
          <span className="text-muted-foreground">{option.unit ?? ""}</span>
        </span>
      </>
    );
  }

  if (option.kind === "choice") {
    const idx = Number(value ?? option.def);
    return (
      <div className="flex w-full items-center justify-between rounded-md bg-surface">
        <button
          aria-label={`Previous ${option.label}`}
          onClick={() => onCycle(option, -1)}
          className="grid size-6 cursor-pointer place-items-center rounded text-muted-foreground transition-colors hover:text-primary"
        >
          <ChevronLeft className="size-3.5" />
        </button>
        <span id={option.id} className="min-w-0 flex-1 truncate text-center text-xs font-medium text-primary">
          {option.choices[idx]}
        </span>
        <button
          aria-label={`Next ${option.label}`}
          onClick={() => onCycle(option, 1)}
          className="grid size-6 cursor-pointer place-items-center rounded text-muted-foreground transition-colors hover:text-primary"
        >
          <ChevronRight className="size-3.5" />
        </button>
      </div>
    );
  }

  return (
    <Button id={option.id} variant="outline" size="sm" className="h-6 w-16 rounded-md px-0 text-[11px]" onClick={() => onActivate(option)}>
      {option.preset ? "Load" : "Run"}
    </Button>
  );
}
