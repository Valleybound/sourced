import { useCallback, useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";

import { AppHeader, StatusFooter } from "@/components/game/app-chrome";
import { GameScene } from "@/components/game/game-scene";
import { applyPreset, DEFAULT_VALUES, PANIC_KEYS, panicValues, THEMES, type MenuValues, type PresetId } from "@/components/game/menu-data";
import { ModMenu } from "@/components/game/mod-menu";
import { toast } from "sonner";

import { cn } from "@/lib/utils";

const STORAGE_KEY = "aurelis:values";

const TITLE = "Aurelis — Pax Dei Mod Menu";
const DESCRIPTION = "Aurelis: a pink and charcoal mod menu mockup for Pax Dei with aimbot, ESP, movement, visuals and configs.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [values, setValues] = useState<MenuValues>(DEFAULT_VALUES);
  const [menuOpen, setMenuOpen] = useState(true);

  const onChange = useCallback((id: string, value: boolean | number) => {
    setValues((v) => ({ ...v, [id]: value }));
  }, []);
  const onPreset = useCallback((preset: PresetId) => setValues((v) => applyPreset(v, preset)), []);
  const onPanic = useCallback(() => {
    setValues((v) => panicValues(v));
    setMenuOpen(false);
    toast.dismiss();
  }, []);
  const panicKey = PANIC_KEYS[Number(values["panicKey"])] ?? "End";

  // Restore saved options once, then keep them saved while "Remember Settings" is on
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null") as MenuValues | null;
      if (saved && saved["autosave"] !== false) setValues({ ...DEFAULT_VALUES, ...saved });
    } catch {
      /* ignore corrupt storage */
    }
    setLoaded(true);
  }, []);
  useEffect(() => {
    if (!loaded) return;
    if (values["autosave"] === false) localStorage.removeItem(STORAGE_KEY);
    else localStorage.setItem(STORAGE_KEY, JSON.stringify(values));
  }, [values, loaded]);

  // Menu theme recolors every accent token through <html data-theme>
  const theme = THEMES[Number(values["menuTheme"])] ?? "pink";
  useEffect(() => {
    document.documentElement.dataset["theme"] = theme;
  }, [theme]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === panicKey) {
        e.preventDefault();
        onPanic();
        return;
      }
      if ((e.target as HTMLElement | null)?.closest("input, textarea")) return;
      if (e.key === "m" || e.key === "M") setMenuOpen((o) => !o);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [panicKey, onPanic]);

  const menuLeft = Number(values["menuSide"]) === 1;

  return (
    <div className="flex min-h-dvh flex-col lg:h-dvh">
      <AppHeader menuOpen={menuOpen} onToggleMenu={() => setMenuOpen((o) => !o)} onPanic={onPanic} panicKey={panicKey} />

      <main className={cn("flex min-h-0 flex-1 flex-col gap-4 p-4 lg:flex-row", menuLeft && "lg:flex-row-reverse")}>
        <div className="h-[56vh] min-h-[360px] min-w-0 flex-1 lg:h-auto">
          <GameScene values={values} menuOpen={menuOpen} />
        </div>
        <div className={cn("shrink-0 lg:w-[500px]", !menuOpen && "hidden")}>
          <ModMenu values={values} onChange={onChange} onPreset={onPreset} open={menuOpen} />
        </div>
      </main>

      <StatusFooter showHints={values["keyHints"] !== false} />
    </div>
  );
}
